# Webapplikasjoner oppgave 2

### Enhetstestingen ligger under mappen test5

### Innloggingsinformasjon til Admin-siden: 
Brukernavn: Admin   
Passord: Admin1
(ligger også i DbInit.cs)

### Forbedringer:
Vi har forbedret de punktene vi fikk tilbakemelding på i oppgave 1. 
- Bruker legger nå også inn epost/kortnummer.
- Designet forbedret slik at inputfeltene ikke kun ligger under hverandre.

### Modal- i index.html er hentet fra: (https://www.w3schools.com/bootstrap/bootstrap_modal.asp)
### Data i databasen: Vi har laget turer på følgende datoer; "12/12/2020", "24/12/2020" og "01/01/2021":
### Innloggingsfunksjon: Hentet fra Tor sin kode. 

#### Gruppe 12: s333975, s197235, s331153, s236808
