﻿function loggUt() {
    $.get("Bestilling/LoggInn", function () {
        window.location.href = "loggInn.html";
    })
}